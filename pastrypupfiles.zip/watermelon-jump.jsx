import { useState, useEffect, useRef, useCallback } from "react";

// ===== Marker palette from the drawings =====
const MELON_RED = "#d9453a";
const MELON_GREEN = "#1f8f5f";
const GRASS = "#1f9e57";
const SUN = "#f2a51e";
const PURPLE = "#7a4fb5";
const BLUE = "#2e6fd9";
const CURTAIN = "#e8544a";
const CURTAIN_PINK = "#f6a3b8";
const INK = "#1b1b1b";
const PAPER = "#fdfaf2";
const SKY = "#fdfaf2";

const font = "'Comic Sans MS', 'Chalkboard SE', 'Comic Neue', cursive";

// ===== physics =====
const GRAVITY = 2400;       // px/s^2
const JUMP_V = -950;        // px/s
const MOVE_SPEED = 260;     // px/s left-right
const GROUND_FRAC = 0.82;   // ground line as fraction of play height
const START_SCROLL = 260;   // world scroll px/s
const SCROLL_RAMP = 8;      // +px/s per second

const W = 340, H = 300; // logical play area, scaled to fit

export default function WatermelonJump() {
  const [screen, setScreen] = useState("title"); // title | play | over
  const [, tick] = useState(0);
  const [best, setBest] = useState(0);

  const g = useRef(null);
  const keys = useRef({});
  const lastT = useRef(0);
  const rafRef = useRef();

  const groundY = H * GROUND_FRAC;

  const newGame = () => ({
    x: 70, y: groundY, vy: 0,
    onGround: true, ducking: false,
    score: 0, scroll: START_SCROLL,
    obstacles: [], nextSpawn: 0.9, t: 0,
    dead: false,
  });

  const startGame = () => { g.current = newGame(); lastT.current = 0; setScreen("play"); };

  // ---- obstacle factory: utensils on ground, condiments flying ----
  const spawn = (state) => {
    const r = Math.random();
    let ob;
    if (r < 0.30) ob = { kind: "fork",   w: 26, h: 62, y: groundY, fly: false };
    else if (r < 0.55) ob = { kind: "spoon", w: 26, h: 52, y: groundY, fly: false };
    else if (r < 0.75) ob = { kind: "knife", w: 22, h: 70, y: groundY, fly: false };
    else if (r < 0.88) ob = { kind: "ketchup", w: 34, h: 26, y: groundY - 58, fly: true };
    else ob = { kind: "mustard", w: 34, h: 26, y: groundY - 58, fly: true };
    ob.x = W + 40;
    ob.scored = false;
    state.obstacles.push(ob);
    state.nextSpawn = 0.75 + Math.random() * 0.9 - Math.min(0.35, state.t * 0.01);
  };

  // ---- input ----
  const press = useCallback((k, down) => { keys.current[k] = down; }, []);
  const jump = useCallback(() => {
    const s = g.current;
    if (screen !== "play" || !s || s.dead) return;
    if (s.onGround) { s.vy = JUMP_V; s.onGround = false; s.ducking = false; }
  }, [screen]);

  useEffect(() => {
    const down = (e) => {
      const k = e.key.toLowerCase();
      if (screen !== "play" && (k === " " || k === "enter")) { startGame(); return; }
      if (k === "arrowup" || k === "w" || k === " ") { e.preventDefault(); jump(); }
      if (k === "arrowdown" || k === "s") { e.preventDefault(); press("duck", true); }
      if (k === "arrowleft" || k === "a") { e.preventDefault(); press("left", true); }
      if (k === "arrowright" || k === "d") { e.preventDefault(); press("right", true); }
    };
    const up = (e) => {
      const k = e.key.toLowerCase();
      if (k === "arrowdown" || k === "s") press("duck", false);
      if (k === "arrowleft" || k === "a") press("left", false);
      if (k === "arrowright" || k === "d") press("right", false);
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, [screen, jump, press]);

  // ---- game loop ----
  useEffect(() => {
    const loop = (t) => {
      rafRef.current = requestAnimationFrame(loop);
      if (screen !== "play" || !g.current) { tick((n) => n + 1); return; }
      if (!lastT.current) { lastT.current = t; return; }
      let dt = Math.min(0.033, (t - lastT.current) / 1000);
      lastT.current = t;
      const s = g.current;
      if (s.dead) { tick((n) => n + 1); return; }

      s.t += dt;
      s.scroll += SCROLL_RAMP * dt;
      s.score += dt * 10;

      // movement
      s.ducking = !!keys.current.duck && s.onGround;
      if (keys.current.left) s.x -= MOVE_SPEED * dt;
      if (keys.current.right) s.x += MOVE_SPEED * dt;
      s.x = Math.max(20, Math.min(W - 50, s.x));

      // gravity
      s.vy += GRAVITY * dt;
      s.y += s.vy * dt;
      if (s.y >= groundY) { s.y = groundY; s.vy = 0; s.onGround = true; }

      // spawn + move obstacles
      s.nextSpawn -= dt;
      if (s.nextSpawn <= 0) spawn(s);
      s.obstacles.forEach((o) => { o.x -= s.scroll * dt; });
      s.obstacles = s.obstacles.filter((o) => o.x > -60);

      // collision (player box)
      const ph = s.ducking ? 26 : 46;
      const pw = 34;
      const px = s.x, py = s.y - ph;
      for (const o of s.obstacles) {
        const ox = o.x, oy = o.y - o.h, ow = o.w, oh = o.h;
        const pad = 6; // forgiving hitbox
        if (px + pad < ox + ow - pad && px + pw - pad > ox + pad &&
            py + pad < oy + oh - pad && py + ph - pad > oy + pad) {
          s.dead = true;
          setBest((b) => Math.max(b, Math.floor(s.score)));
          setTimeout(() => setScreen("over"), 700);
        }
        if (!o.scored && o.x + o.w < s.x) { o.scored = true; s.score += 5; }
      }
      tick((n) => n + 1);
    };
    rafRef.current = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(rafRef.current);
  }, [screen]);

  // ===== SPRITES =====
  const Watermelon = ({ s }) => {
    const duck = s.ducking;
    const hop = !s.onGround;
    return (
      <g transform={`translate(${s.x}, ${s.y}) scale(${duck ? 1.15 : 1}, ${duck ? 0.6 : 1})`}>
        {/* legs */}
        <path d={hop ? "M 10 -4 l -6 8 M 24 -4 l 6 8" : "M 12 -4 l -3 6 M 22 -4 l 3 6"}
          stroke="#8a5a2b" strokeWidth="4" strokeLinecap="round" fill="none" />
        {/* rind */}
        <path d="M 2 -12 Q 17 -2 32 -12 L 30 -4 Q 17 4 4 -4 Z" fill={MELON_GREEN} stroke={INK} strokeWidth="2.5" />
        {/* flesh triangle */}
        <path d="M 17 -46 L 33 -11 Q 17 -2 1 -11 Z" fill={MELON_RED} stroke={INK} strokeWidth="2.5" />
        {/* seeds */}
        <ellipse cx="12" cy="-22" rx="1.8" ry="2.8" fill={INK} />
        <ellipse cx="22" cy="-18" rx="1.8" ry="2.8" fill={INK} />
        <ellipse cx="17" cy="-32" rx="1.8" ry="2.8" fill={INK} />
        {/* face */}
        <circle cx="13" cy="-26" r="1.6" fill={INK} />
        <circle cx="21" cy="-26" r="1.6" fill={INK} />
        <path d="M 12 -20 Q 17 -15 22 -20" stroke={INK} strokeWidth="2" fill="none" strokeLinecap="round" />
        {/* arms up like the drawing */}
        <path d={hop ? "M 5 -28 l -10 -10 M 29 -28 l 10 -10" : "M 5 -26 l -9 -6 M 29 -26 l 9 -6"}
          stroke={MELON_GREEN} strokeWidth="4.5" strokeLinecap="round" fill="none" />
      </g>
    );
  };

  const Obstacle = ({ o }) => {
    const base = `translate(${o.x}, ${o.y})`;
    if (o.kind === "fork")
      return (<g transform={base} stroke="#8b8b8b" strokeWidth="5" strokeLinecap="round">
        <line x1="13" y1="0" x2="13" y2={-o.h + 18} />
        <path d={`M 4 ${-o.h + 18} v -14 M 13 ${-o.h + 18} v -16 M 22 ${-o.h + 18} v -14 M 4 ${-o.h + 16} h 18`} fill="none" strokeWidth="3.5" />
      </g>);
    if (o.kind === "spoon")
      return (<g transform={base}>
        <line x1="13" y1="0" x2="13" y2={-o.h + 16} stroke="#8b8b8b" strokeWidth="5" strokeLinecap="round" />
        <ellipse cx="13" cy={-o.h + 10} rx="11" ry="13" fill="#c9c9c9" stroke="#8b8b8b" strokeWidth="3" />
      </g>);
    if (o.kind === "knife")
      return (<g transform={base}>
        <line x1="11" y1="0" x2="11" y2="-26" stroke="#8b8b8b" strokeWidth="5" strokeLinecap="round" />
        <path d={`M 4 -26 L 4 ${-o.h} Q 18 ${-o.h + 14} 18 -26 Z`} fill="#d8d8d8" stroke="#8b8b8b" strokeWidth="3" />
      </g>);
    // flying condiments
    const col = o.kind === "ketchup" ? "#d9453a" : "#e8b31e";
    const label = o.kind === "ketchup" ? "K" : "M";
    return (<g transform={base}>
      <rect x="0" y={-o.h} width={o.w} height={o.h} rx="8" fill={col} stroke={INK} strokeWidth="2.5" />
      <rect x={o.w - 6} y={-o.h + 8} width="8" height="8" rx="2" fill={col} stroke={INK} strokeWidth="2" />
      <text x={o.w / 2 - 4} y={-o.h / 2 + 5} fontFamily={font} fontWeight="700" fontSize="14" fill="#fff">{label}</text>
    </g>);
  };

  const s = g.current;

  // ===== on-screen controls =====
  const CtlBtn = ({ label, style, onDown, onUp, onTap }) => {
    const hs = onTap
      ? { onTouchStart: (e) => { e.preventDefault(); onTap(); }, onMouseDown: onTap }
      : {
          onTouchStart: (e) => { e.preventDefault(); onDown(); },
          onTouchEnd: (e) => { e.preventDefault(); onUp(); },
          onMouseDown: onDown, onMouseUp: onUp, onMouseLeave: onUp,
        };
    return <button {...hs} style={{
      fontFamily: font, fontWeight: 700, fontSize: 15, color: "#fff",
      background: PURPLE, border: `3px solid ${INK}`, borderRadius: 12,
      boxShadow: `2px 2px 0 ${INK}`, touchAction: "none", userSelect: "none",
      WebkitUserSelect: "none", cursor: "pointer", padding: 0, ...style,
    }}>{label}</button>;
  };

  return (
    <div style={{
      minHeight: "100vh", background: "#2a2a2e", display: "flex",
      alignItems: "center", justifyContent: "center", padding: 10, fontFamily: font,
    }}>
      {/* ===== Paper Game Boy console, like the drawing ===== */}
      <div style={{
        background: PAPER, border: `4px solid ${INK}`, borderRadius: "18px 18px 26px 26px",
        padding: "12px 12px 16px", width: "min(96vw, 430px)",
        boxShadow: "6px 8px 0 rgba(0,0,0,0.45)",
      }}>
        {/* screen bezel with theater curtains */}
        <div style={{ position: "relative", border: `4px solid ${INK}`, borderRadius: 10, overflow: "hidden", background: SKY }}>
          {/* top curtain rail */}
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 12, background: SUN, borderBottom: `3px solid ${INK}`, zIndex: 5 }} />
          <div style={{ position: "absolute", top: 12, left: 0, width: 26, bottom: 0, background: `linear-gradient(90deg, ${CURTAIN}, ${CURTAIN_PINK})`, borderRight: `3px solid ${INK}`, zIndex: 5 }} />
          <div style={{ position: "absolute", top: 12, right: 0, width: 26, bottom: 0, background: `linear-gradient(-90deg, ${CURTAIN}, ${CURTAIN_PINK})`, borderLeft: `3px solid ${INK}`, zIndex: 5 }} />

          {/* game screen */}
          <svg viewBox={`0 0 ${W} ${H}`} style={{ display: "block", width: "100%", height: "auto" }}>
            {/* sun */}
            <g transform="translate(300, 42)">
              <circle r="18" fill={SUN} stroke={INK} strokeWidth="2.5" />
              {[...Array(8)].map((_, i) => {
                const a = (i / 8) * Math.PI * 2;
                return <line key={i} x1={Math.cos(a) * 22} y1={Math.sin(a) * 22} x2={Math.cos(a) * 30} y2={Math.sin(a) * 30} stroke={SUN} strokeWidth="4" strokeLinecap="round" />;
              })}
            </g>

            {screen === "title" && (
              <g>
                <text x={W / 2} y="100" textAnchor="middle" fontFamily={font} fontWeight="700" fontSize="34" fill={MELON_RED} stroke={INK} strokeWidth="1" transform={`rotate(-2 ${W / 2} 100)`}>Watermelon</text>
                <text x={W / 2} y="140" textAnchor="middle" fontFamily={font} fontWeight="700" fontSize="34" fill={MELON_GREEN} stroke={INK} strokeWidth="1" transform={`rotate(1 ${W / 2} 140)`}>Jump!</text>
                <text x={W / 2} y="180" textAnchor="middle" fontFamily={font} fontSize="14" fill={INK}>Jump over the utensils!</text>
                <text x={W / 2} y="200" textAnchor="middle" fontFamily={font} fontSize="14" fill={INK}>Duck under flying condiments!</text>
                {/* hearts like the drawing */}
                <text x="60" y="120" fontSize="20">💕</text>
                <text x="265" y="170" fontSize="20">💕</text>
              </g>
            )}

            {screen === "over" && s && (
              <g>
                <text x={W / 2} y="105" textAnchor="middle" fontFamily={font} fontWeight="700" fontSize="30" fill={INK}>SPLAT!</text>
                <text x={W / 2} y="140" textAnchor="middle" fontFamily={font} fontSize="18" fill={INK}>Score: {Math.floor(s.score)}</text>
                <text x={W / 2} y="165" textAnchor="middle" fontFamily={font} fontSize="15" fill={PURPLE}>Best: {best}</text>
              </g>
            )}

            {/* grass ground — scribble style */}
            <rect x="0" y={groundY} width={W} height={H - groundY} fill={GRASS} />
            {[...Array(24)].map((_, i) => (
              <path key={i} d={`M ${i * 15 + ((s ? -s.t * 60 : 0) % 15)} ${groundY} q 4 -12 8 0`} stroke={GRASS} strokeWidth="4" fill="none" />
            ))}
            <line x1="0" y1={groundY} x2={W} y2={groundY} stroke={INK} strokeWidth="3" />

            {/* obstacles + player */}
            {s && screen === "play" && s.obstacles.map((o, i) => <Obstacle key={i} o={o} />)}
            {s && screen === "play" && <Watermelon s={s} />}

            {/* score */}
            {s && screen === "play" && (
              <text x="14" y="28" fontFamily={font} fontWeight="700" fontSize="18" fill={INK}>⭐ {Math.floor(s.score)}</text>
            )}
          </svg>
        </div>

        {/* ===== console controls, like the drawing ===== */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginTop: 14, gap: 10 }}>
          {/* purple d-pad */}
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 46px)", gridTemplateRows: "repeat(3, 46px)", gap: 2 }}>
            <div />
            <CtlBtn label="▲" onTap={jump} style={{ gridColumn: 2 }} />
            <div />
            <CtlBtn label="◀" onDown={() => press("left", true)} onUp={() => press("left", false)} />
            <div style={{ background: PURPLE, border: `3px solid ${INK}`, borderRadius: 6 }} />
            <CtlBtn label="▶" onDown={() => press("right", true)} onUp={() => press("right", false)} />
            <div />
            <CtlBtn label="▼" onDown={() => press("duck", true)} onUp={() => press("duck", false)} style={{ gridColumn: 2 }} />
            <div />
          </div>

          {/* start pill + green speaker */}
          <div style={{ display: "flex", flexDirection: "column", gap: 10, alignItems: "center" }}>
            <button onClick={startGame} style={{
              fontFamily: font, fontWeight: 700, fontSize: 16, color: "#fff",
              background: BLUE, border: `3px solid ${INK}`, borderRadius: 20,
              padding: "8px 26px", boxShadow: `2px 2px 0 ${INK}`, cursor: "pointer",
              transform: "rotate(-1deg)",
            }}>{screen === "play" ? "restart" : "Start!"}</button>
            {/* green speaker grille with the :0! face, like the drawing */}
            <div style={{
              background: MELON_GREEN, border: `3px solid ${INK}`, borderRadius: 8,
              padding: "6px 14px", fontFamily: font, fontWeight: 700, fontSize: 18,
              color: INK, letterSpacing: 3, transform: "rotate(1deg)",
            }}>: 0 !</div>
          </div>
        </div>

        <div style={{ textAlign: "center", marginTop: 10, fontSize: 12, color: "#666", fontFamily: font }}>
          keyboard: ← → move · ↑/space jump · ↓ duck
        </div>
      </div>
    </div>
  );
}
