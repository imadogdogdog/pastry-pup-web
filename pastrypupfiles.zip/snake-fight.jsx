import { useState, useEffect, useRef, useCallback } from "react";

// ============ GAME CONSTANTS ============
const MAX_HP = 100;
const BITE_DMG = 22;
const STRIKE_DMG = 10;
const BITE_WINDUP = 350;   // ms before bite lands
const STRIKE_WINDUP = 160; // ms before strike lands
const BITE_COOLDOWN = 900;
const STRIKE_COOLDOWN = 450;
const JUMP_TIME = 500;
const CROUCH_TIME = 500;

// Marker palette from the drawing
const TEAL = "#1a9e9e";
const DARKTEAL = "#0e6b6b";
const RED = "#d33a2c";
const PINK = "#f286b0";
const ORANGE = "#f0a622";
const GREEN = "#2e9e4f";
const INK = "#1b1b1b";
const PAPER = "#fdfaf2";

const font = "'Comic Sans MS', 'Chalkboard SE', 'Comic Neue', cursive";

function makePlayer() {
  return {
    hp: MAX_HP,
    state: "idle", // idle | jump | crouch | block | bite | strike | hit | ko
    stateUntil: 0,
    cooldownUntil: 0,
    blocking: false,
  };
}

export default function SnakeFight() {
  const [screen, setScreen] = useState("title"); // title | fight | over
  const [winner, setWinner] = useState(null);
  const [, forceRender] = useState(0);
  const p1 = useRef(makePlayer());
  const p2 = useRef(makePlayer());
  const [flash, setFlash] = useState(null); // {who, text, color}
  const rafRef = useRef();

  const now = () => performance.now();

  const showFlash = (who, text, color) => {
    setFlash({ who, text, color, id: Math.random() });
    setTimeout(() => setFlash((f) => (f && f.text === text ? null : f)), 600);
  };

  const resetGame = () => {
    p1.current = makePlayer();
    p2.current = makePlayer();
    setWinner(null);
    setFlash(null);
    setScreen("fight");
  };

  // ---- resolve an attack from attacker onto defender ----
  const resolveAttack = useCallback((atk, def, kind, atkName, defName) => {
    const t = now();
    if (def.current.hp <= 0 || atk.current.hp <= 0) return;
    const d = def.current;
    if (kind === "bite") {
      if (d.state === "jump") { showFlash(defName, "DODGED!", GREEN); return; }
      let dmg = BITE_DMG;
      if (d.state === "block") { dmg = Math.ceil(dmg / 4); showFlash(defName, "BLOCKED!", TEAL); }
      else showFlash(defName, "CHOMP! -" + dmg, RED);
      d.hp = Math.max(0, d.hp - dmg);
    } else {
      if (d.state === "crouch") { showFlash(defName, "DUCKED!", GREEN); return; }
      let dmg = STRIKE_DMG;
      if (d.state === "block") { dmg = Math.ceil(dmg / 4); showFlash(defName, "BLOCKED!", TEAL); }
      else showFlash(defName, "STRIKE! -" + dmg, ORANGE);
      d.hp = Math.max(0, d.hp - dmg);
    }
    if (d.hp <= 0) {
      d.state = "ko";
      setWinner(atkName);
      setTimeout(() => setScreen("over"), 900);
    } else if (d.state !== "block" && d.state !== "jump" && d.state !== "crouch") {
      d.state = "hit";
      d.stateUntil = t + 300;
    }
  }, []);

  // ---- perform action for a player ----
  const doAction = useCallback((who, action) => {
    if (screen !== "fight") return;
    const me = who === 1 ? p1 : p2;
    const other = who === 1 ? p2 : p1;
    const myName = who === 1 ? "P1" : "P2";
    const otherName = who === 1 ? "P2" : "P1";
    const t = now();
    const m = me.current;
    if (m.hp <= 0) return;
    if (m.state === "bite" || m.state === "strike") return; // mid-attack

    switch (action) {
      case "jump":
        m.state = "jump"; m.stateUntil = t + JUMP_TIME; break;
      case "crouch":
        m.state = "crouch"; m.stateUntil = t + CROUCH_TIME; break;
      case "blockOn":
        m.blocking = true; m.state = "block"; m.stateUntil = Infinity; break;
      case "blockOff":
        m.blocking = false;
        if (m.state === "block") { m.state = "idle"; m.stateUntil = 0; }
        break;
      case "bite":
        if (t < m.cooldownUntil) return;
        m.state = "bite"; m.stateUntil = t + BITE_WINDUP;
        m.cooldownUntil = t + BITE_COOLDOWN;
        setTimeout(() => {
          resolveAttack(me, other, "bite", myName, otherName);
          if (me.current.state === "bite") {
            me.current.state = me.current.blocking ? "block" : "idle";
            me.current.stateUntil = me.current.blocking ? Infinity : 0;
          }
        }, BITE_WINDUP);
        break;
      case "strike":
        if (t < m.cooldownUntil) return;
        m.state = "strike"; m.stateUntil = t + STRIKE_WINDUP;
        m.cooldownUntil = t + STRIKE_COOLDOWN;
        setTimeout(() => {
          resolveAttack(me, other, "strike", myName, otherName);
          if (me.current.state === "strike") {
            me.current.state = me.current.blocking ? "block" : "idle";
            me.current.stateUntil = me.current.blocking ? Infinity : 0;
          }
        }, STRIKE_WINDUP);
        break;
      default: break;
    }
  }, [screen, resolveAttack]);

  // ---- game loop: expire timed states, re-render ----
  useEffect(() => {
    const tick = () => {
      const t = now();
      [p1, p2].forEach((p) => {
        const m = p.current;
        if (m.state !== "idle" && m.state !== "ko" && m.state !== "block" && t > m.stateUntil) {
          m.state = m.blocking ? "block" : "idle";
          m.stateUntil = m.blocking ? Infinity : 0;
        }
      });
      forceRender((n) => n + 1);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  // ---- keyboard ----
  useEffect(() => {
    const down = (e) => {
      if (screen === "title" && (e.key === "Enter" || e.key === " ")) { resetGame(); return; }
      if (screen === "over" && (e.key === "Enter" || e.key === " ")) { resetGame(); return; }
      if (e.repeat) return;
      switch (e.key.toLowerCase()) {
        // P1: WASD + F (bite) + G (strike)
        case "w": doAction(1, "jump"); break;
        case "s": doAction(1, "crouch"); break;
        case "a": case "d": doAction(1, "blockOn"); break;
        case "f": doAction(1, "bite"); break;
        case "g": doAction(1, "strike"); break;
        // P2: arrows + K (bite) + L (strike)
        case "arrowup": e.preventDefault(); doAction(2, "jump"); break;
        case "arrowdown": e.preventDefault(); doAction(2, "crouch"); break;
        case "arrowleft": case "arrowright": e.preventDefault(); doAction(2, "blockOn"); break;
        case "k": doAction(2, "bite"); break;
        case "l": doAction(2, "strike"); break;
        default: break;
      }
    };
    const up = (e) => {
      switch (e.key.toLowerCase()) {
        case "a": case "d": doAction(1, "blockOff"); break;
        case "arrowleft": case "arrowright": doAction(2, "blockOff"); break;
        default: break;
      }
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, [screen, doAction]);

  // ============ SNAKE DRAWING ============
  const Snake = ({ player, flip, color }) => {
    const st = player.state;
    const jumpY = st === "jump" ? -46 : 0;
    const crouchY = st === "crouch" ? 22 : 0;
    const lunge = st === "bite" ? (flip ? -34 : 34) : st === "strike" ? (flip ? -20 : 20) : 0;
    const shake = st === "hit" ? (Math.random() * 8 - 4) : 0;
    const koRot = st === "ko" ? (flip ? 80 : -80) : 0;
    const mouthOpen = st === "bite" ? 26 : st === "strike" ? 10 : 4;
    return (
      <div style={{
        transform: `translate(${lunge + shake}px, ${jumpY + crouchY}px) rotate(${koRot}deg) scaleX(${flip ? -1 : 1}) ${st === "crouch" ? "scaleY(0.72)" : ""}`,
        transition: st === "hit" ? "none" : "transform 120ms ease-out",
        transformOrigin: "center bottom",
      }}>
        <svg width="150" height="130" viewBox="0 0 150 130">
          {/* body squiggle — like the marker drawing */}
          <path
            d="M8 118 Q 22 84 40 104 Q 58 124 68 92 Q 78 60 96 78 Q 110 92 118 70"
            fill="none" stroke={INK} strokeWidth="17" strokeLinecap="round" />
          <path
            d="M8 118 Q 22 84 40 104 Q 58 124 68 92 Q 78 60 96 78 Q 110 92 118 70"
            fill="none" stroke={color} strokeWidth="10" strokeLinecap="round" />
          {/* head */}
          <g transform="translate(118,60)">
            <ellipse cx="8" cy="6" rx="21" ry="15" fill={color} stroke={INK} strokeWidth="3.5" />
            {/* mouth */}
            <path d={`M 22 6 L 32 ${6 - mouthOpen / 2} M 22 6 L 32 ${6 + mouthOpen / 2}`}
              stroke={INK} strokeWidth="3.5" strokeLinecap="round" fill="none" />
            {/* fang when biting */}
            {st === "bite" && <path d="M 26 0 l 3 6 l 3 -6 z" fill="#fff" stroke={INK} strokeWidth="1.5" />}
            {/* eye */}
            <circle cx="8" cy="0" r="4.5" fill="#fff" stroke={INK} strokeWidth="2" />
            <circle cx="9.5" cy="0" r="2" fill={INK} />
            {st === "ko" && <text x="3" y="4" fontSize="12" fontFamily={font} fill={INK}>x</text>}
            {/* tongue on strike */}
            {st === "strike" && <path d="M 30 6 h 14 l -4 -4 m 4 4 l -4 4" stroke={RED} strokeWidth="3" fill="none" strokeLinecap="round" />}
          </g>
          {/* shield when blocking */}
          {st === "block" && (
            <g transform="translate(136,52)">
              <ellipse cx="0" cy="14" rx="10" ry="22" fill={PINK} stroke={INK} strokeWidth="3" opacity="0.9" />
            </g>
          )}
        </svg>
      </div>
    );
  };

  // ============ HP BAR ============
  const HpBar = ({ hp, name, color, flip }) => (
    <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: flip ? "flex-end" : "flex-start", gap: 3 }}>
      <div style={{ fontFamily: font, fontWeight: 700, fontSize: 15, color: INK, background: color, padding: "1px 10px", borderRadius: 6, border: `2.5px solid ${INK}`, transform: "rotate(-1.5deg)" }}>{name}</div>
      <div style={{ width: "100%", height: 20, border: `3px solid ${INK}`, borderRadius: 8, background: "#fff", overflow: "hidden", transform: flip ? "rotate(0.8deg)" : "rotate(-0.8deg)" }}>
        <div style={{
          width: `${(hp / MAX_HP) * 100}%`, height: "100%",
          background: hp > 40 ? GREEN : hp > 15 ? ORANGE : RED,
          transition: "width 200ms ease-out, background 200ms",
          marginLeft: flip ? "auto" : 0,
        }} />
      </div>
    </div>
  );

  // ============ CONTROLLER (styled like the drawing) ============
  const Pad = ({ who, accent }) => {
    const btn = (label, action, style, hold) => {
      const handlers = hold
        ? {
            onTouchStart: (e) => { e.preventDefault(); doAction(who, "blockOn"); },
            onTouchEnd: (e) => { e.preventDefault(); doAction(who, "blockOff"); },
            onMouseDown: () => doAction(who, "blockOn"),
            onMouseUp: () => doAction(who, "blockOff"),
            onMouseLeave: () => doAction(who, "blockOff"),
          }
        : {
            onTouchStart: (e) => { e.preventDefault(); doAction(who, action); },
            onMouseDown: () => doAction(who, action),
          };
      return (
        <button {...handlers} style={{
          fontFamily: font, fontWeight: 700, border: `3px solid ${INK}`,
          background: PAPER, color: INK, borderRadius: 10,
          touchAction: "none", userSelect: "none", WebkitUserSelect: "none",
          fontSize: 13, lineHeight: 1.1, padding: 0,
          boxShadow: `2px 2px 0 ${INK}`,
          cursor: "pointer", ...style,
        }}>{label}</button>
      );
    };
    const cell = 44;
    return (
      <div style={{
        background: PAPER, border: `3px solid ${INK}`, borderRadius: 14,
        padding: 10, display: "flex", alignItems: "center", gap: 12,
        transform: who === 1 ? "rotate(-1deg)" : "rotate(1deg)",
        boxShadow: `3px 3px 0 rgba(0,0,0,0.25)`,
      }}>
        {/* D-pad */}
        <div style={{ display: "grid", gridTemplateColumns: `repeat(3, ${cell}px)`, gridTemplateRows: `repeat(3, ${cell}px)`, gap: 3 }}>
          <div />{btn("▲ dodge", "jump", { gridColumn: 2, background: "#cdeeee" })}<div />
          {btn("◀ block", null, { background: "#cdeeee" }, true)}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", fontFamily: font, fontSize: 10, color: DARKTEAL }}>P{who}</div>
          {btn("block ▶", null, { background: "#cdeeee" }, true)}
          <div />{btn("▼ crouch", "crouch", { gridColumn: 2, background: "#cdeeee" })}<div />
        </div>
        {/* Action buttons */}
        <div style={{ display: "flex", flexDirection: "column", gap: 8, alignItems: "center" }}>
          {btn("BITE", "bite", { width: 66, height: 66, borderRadius: "50%", background: accent, color: "#fff", fontSize: 15, textShadow: `1px 1px 0 ${INK}` })}
          {btn("strike", "strike", { width: 50, height: 34, borderRadius: 17, background: ORANGE })}
        </div>
      </div>
    );
  };

  // ============ SCREENS ============
  const paperBg = {
    minHeight: "100vh", width: "100%", background: PAPER,
    backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 26px, rgba(26,158,158,0.08) 27px)`,
    fontFamily: font, display: "flex", flexDirection: "column",
    overflow: "hidden", position: "relative",
  };

  if (screen === "title") {
    return (
      <div style={{ ...paperBg, alignItems: "center", justifyContent: "center", gap: 18, padding: 20 }}>
        <svg width="200" height="70" viewBox="0 0 200 70">
          <path d="M10 55 Q 35 15 60 45 Q 85 75 110 40 Q 135 10 160 40 Q 175 58 190 35"
            fill="none" stroke={INK} strokeWidth="16" strokeLinecap="round" />
          <path d="M10 55 Q 35 15 60 45 Q 85 75 110 40 Q 135 10 160 40 Q 175 58 190 35"
            fill="none" stroke={TEAL} strokeWidth="9" strokeLinecap="round" />
        </svg>
        <h1 style={{ margin: 0, fontSize: "clamp(34px, 9vw, 64px)", color: INK, transform: "rotate(-2deg)", textAlign: "center" }}>
          SNAKE <span style={{ color: RED }}>FIGHT!</span>
        </h1>
        <div style={{ background: "#fff", border: `3px solid ${INK}`, borderRadius: 12, padding: "12px 18px", maxWidth: 420, transform: "rotate(0.6deg)", fontSize: 15, lineHeight: 1.6 }}>
          <b>▲</b> dodge / jump (avoids BITE) &nbsp;·&nbsp; <b>▼</b> crouch (avoids strike)<br />
          <b>◀ ▶</b> hold to block (way less damage)<br />
          <b style={{ color: RED }}>BIG BUTTON</b> = BITE (slow, big chomp)<br />
          <b style={{ color: "#b07400" }}>middle button</b> = strike (fast jab)<br />
          <span style={{ fontSize: 13, color: "#666" }}>Keyboard — P1: W A S D + F/G · P2: arrows + K/L</span>
        </div>
        <button onClick={resetGame} style={{
          fontFamily: font, fontSize: 24, fontWeight: 700, padding: "12px 36px",
          background: ORANGE, border: `4px solid ${INK}`, borderRadius: 14,
          boxShadow: `4px 4px 0 ${INK}`, cursor: "pointer", transform: "rotate(-1deg)",
        }}>▶ START</button>
      </div>
    );
  }

  if (screen === "over") {
    const wColor = winner === "P1" ? TEAL : GREEN;
    return (
      <div style={{ ...paperBg, alignItems: "center", justifyContent: "center", gap: 20, padding: 20 }}>
        <h1 style={{ margin: 0, fontSize: "clamp(30px, 8vw, 56px)", transform: "rotate(-2deg)", color: INK }}>
          <span style={{ background: wColor, color: "#fff", padding: "2px 14px", borderRadius: 10, border: `4px solid ${INK}` }}>{winner}</span> WINS!
        </h1>
        <div style={{ fontSize: 40 }}>🏆</div>
        <button onClick={resetGame} style={{
          fontFamily: font, fontSize: 22, fontWeight: 700, padding: "12px 32px",
          background: PINK, border: `4px solid ${INK}`, borderRadius: 14,
          boxShadow: `4px 4px 0 ${INK}`, cursor: "pointer",
        }}>↻ REMATCH</button>
      </div>
    );
  }

  // fight screen
  const A = p1.current, B = p2.current;
  return (
    <div style={paperBg}>
      {/* HP bars */}
      <div style={{ display: "flex", gap: 14, padding: "12px 14px 4px", alignItems: "flex-start" }}>
        <HpBar hp={A.hp} name="P1" color={TEAL} flip={false} />
        <div style={{ fontSize: 22, fontWeight: 700, paddingTop: 2 }}>VS</div>
        <HpBar hp={B.hp} name="P2" color={GREEN} flip={true} />
      </div>

      {/* Arena */}
      <div style={{ flex: 1, position: "relative", display: "flex", alignItems: "flex-end", justifyContent: "center", gap: "6vw", paddingBottom: 8, minHeight: 170 }}>
        {/* red zigzag ground, like the drawing */}
        <svg style={{ position: "absolute", bottom: 0, left: 0, width: "100%", height: 26 }} preserveAspectRatio="none" viewBox="0 0 400 26">
          <path d="M0 20 L20 6 L40 20 L60 6 L80 20 L100 6 L120 20 L140 6 L160 20 L180 6 L200 20 L220 6 L240 20 L260 6 L280 20 L300 6 L320 20 L340 6 L360 20 L380 6 L400 20"
            fill="none" stroke={RED} strokeWidth="7" strokeLinecap="round" />
        </svg>
        {/* flash text */}
        {flash && (
          <div key={flash.id} style={{
            position: "absolute", top: 8, left: flash.who === "P1" ? "18%" : undefined, right: flash.who === "P2" ? "18%" : undefined,
            fontFamily: font, fontWeight: 700, fontSize: 24, color: "#fff",
            background: flash.color, border: `3px solid ${INK}`, padding: "2px 12px",
            borderRadius: 10, transform: "rotate(-4deg)", boxShadow: `2px 2px 0 ${INK}`,
            animation: "pop 0.6s ease-out",
          }}>{flash.text}</div>
        )}
        <Snake player={A} flip={false} color={TEAL} />
        <Snake player={B} flip={true} color={GREEN} />
      </div>

      {/* Controllers */}
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, padding: "6px 8px 14px", flexWrap: "wrap" }}>
        <Pad who={1} accent={TEAL} />
        <Pad who={2} accent={GREEN} />
      </div>

      <style>{`
        @keyframes pop { 0% { transform: scale(0.4) rotate(-4deg); opacity: 0; } 40% { transform: scale(1.15) rotate(-4deg); opacity: 1; } 100% { transform: scale(1) rotate(-4deg); } }
        button:active { transform: translate(2px,2px); box-shadow: 0 0 0 ${INK} !important; }
        @media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
      `}</style>
    </div>
  );
}
