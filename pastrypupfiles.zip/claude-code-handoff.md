# Handoff: Add Snake Battle + Watermelon Jump to Pastry Pup Arcade

## Context
Repo: `imadogdogdog/pastry-pup-web`, live at pastrypup.shop (GitHub Pages).
Single file: `index.html`. No build step — React 18.3.1 and Firebase 10.12.5
are loaded via an import map (`<script type="importmap">`), and the app
component is written as JSX inside `<script type="text/babel" data-type="module">`,
transpiled in-browser by Babel standalone. Styling is Tailwind via the CDN script.

The app already has:
- A `view` state var in the root `App` component that acts as a router
  (`"home"`, `"arcade"`, `"catching-treats"`, `"wof-quiz"`, `"disney-quiz"`).
- An `ArcadeMenu` component that renders `ArcadeCard` tiles, each calling
  `setView(...)` on click.
- Firebase already initialized (`initializeApp`, `getFirestore`, `getAuth`),
  with **anonymous** sign-in already wired via `signInAnonymously` — no
  Google popup, no OAuth screen. Firestore docs are namespaced under
  `artifacts/{appId}/public/data/{collectionName}` (see `menuItems` for the
  existing pattern), where `appId = "pastry-pup-final"`.

## Goal
Add two more arcade games as new views/cards, matching the existing code
style exactly (ES module JSX, Tailwind classes for any chrome, no external
CSS frameworks beyond Tailwind).

## Games to add
Two working reference implementations are attached (`snake-fight.jsx`,
`watermelon-jump.jsx`). They were built as **standalone classic-script**
React components (assume a global `React`/hooks), so they need converting
to import `useState`/`useEffect`/`useRef`/`useCallback` from `"react"` like
the rest of this file already does. Keep all game logic, physics, and SVG
art as-is — only the import/wrapping style needs to change.

**1. Snake Battle** — 2-player local fighting game (both players share one
keyboard/screen). Marker-drawn snake sprites, bite/strike/block/dodge/crouch
mechanics, HP bars. No login needed — it's local multiplayer, not a
leaderboard game.

**2. Watermelon Jump** — 1-player endless runner (Flappy Bird / Mario style).
Jump over utensils (fork/spoon/knife), duck under flying condiments
(ketchup/mustard). Score increases over time + per obstacle cleared. This
one should write to a **leaderboard**.

## Leaderboard requirements (Watermelon Jump only)
- Reuse the site's existing anonymous auth — do **not** add Google
  sign-in or any popup/redirect flow (explicitly wanted: no new tab, no
  OAuth screen).
- First time a player gets a game-over screen, prompt once for a nickname
  (simple text input in the game-over card, not a native `prompt()` if
  avoidable) and store it in `localStorage` so it's remembered.
- Store scores in Firestore at
  `artifacts/pastry-pup-final/public/data/watermelonScores/{anonUid}`,
  fields: `{ name, bestScore, updatedAt }`. Only write if the new score
  beats the stored `bestScore` (use a transaction or get-then-set).
- Show a top-10 leaderboard (`orderBy("bestScore","desc"), limit(10)`) via
  `onSnapshot` — display it on the Watermelon Jump title screen and/or
  game-over screen.
- If Firestore isn't configured/reachable, fail quietly (console.error only)
  — same defensive pattern the existing `menuItems` code already uses for
  a missing `db`.

## Integration checklist
- [ ] Add `"snake-battle"` and `"watermelon-jump"` cases to `renderView()`.
- [ ] Add two `ArcadeCard` entries in `ArcadeMenu` (pick icons/colors that
      fit the existing pink/purple/orange/blue palette).
- [ ] Convert both game components to ES-module-style imports.
- [ ] Wire the leaderboard as described above, scoped to Watermelon Jump.
- [ ] Confirm both games' `onExit` props route back to `"arcade"`, matching
      how `CatchingTreatsGame` and `PersonalityQuiz` already do it.
- [ ] Sanity check in a local server (e.g. `npx serve`) before pushing —
      there's no build step, so a JSX typo just fails silently in-browser.

## Attached files
- `snake-fight.jsx` — reference implementation, needs import conversion.
- `watermelon-jump.jsx` — reference implementation, needs import conversion
  + leaderboard wiring.
